from .main import run_ads
